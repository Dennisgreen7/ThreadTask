﻿using System;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            NumNumThreads numnum1 = new NumNumThreads("numnum1");
            NumNumThreads numnum2 = new NumNumThreads("numnum2");
            NumNumThreads numnum3 = new NumNumThreads("numnum3");
            NumNumThreads numnum4 = new NumNumThreads("numnum4");
            Console.WriteLine("Starting threads");
            numnum1.thread.Start();
            numnum2.thread.Start();
            numnum3.thread.Start();
            numnum4.thread.Start();
            numnum1.thread.Join();
            numnum2.thread.Join();
            numnum3.thread.Join();
            numnum4.thread.Join();
            Console.WriteLine("Threads started");
            Console.ReadLine();
        }
    }
}
