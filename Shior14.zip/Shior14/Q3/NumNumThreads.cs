﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Q3
{
    public class NumNumThreads
    {
        public Thread thread;
        public int SleepTime { get; set; }

        public NumNumThreads(string threadName)
        {
            thread = new Thread(() => Sleep());
            SleepTime = new Random().Next(5);
            thread.Name = threadName;
            Console.WriteLine("Thread: "+ thread.Name +" Sleep time:"+ SleepTime +" seconds");
        }

        public void Sleep()
        {
            Console.WriteLine(thread.Name+" going to sleep");
            Thread.Sleep(SleepTime);
            Console.WriteLine(thread.Name+" done sleeping");

        }
    }
}
