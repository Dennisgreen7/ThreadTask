﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Q3
{
    class NumNumTasks
    {
        public Task task;
        public int SleepTime { get; set; }

        public NumNumTasks(string taskName)
        {
            task = new Task(() => Sleep());
            SleepTime = new Random().Next(5);
            Console.WriteLine("Task: "+ task.Id +" Sleep time: " +SleepTime+" seconds");
        }

        public void Sleep()
        {
            Console.WriteLine("Task: "+task.Id+ " going to sleep");
            Thread.Sleep(SleepTime);
            Console.WriteLine("Task: " + task.Id + " done sleeping");
        }
    }
}
