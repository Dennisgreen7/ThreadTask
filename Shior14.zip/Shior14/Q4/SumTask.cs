﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    public class SumTask
    {
        public int Result { get; set; }
        object lockObject = new object();

        public SumTask(int num)
        {
            Task.Run(() =>
            {
                for (int i = 0; i <= num; i++)
                {
                    lock (lockObject)
                    {
                        Result += i;
                    }
                }
            });
        }
    }
}
