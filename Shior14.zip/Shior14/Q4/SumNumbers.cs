﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Q4
{
    public class SumNumbers
    {
        public int Result { get; set; }
        object lockObject = new object();

        public SumNumbers(int num)
        {
            for (int i = 0; i < num / 200000; i++)
            {
                new Thread(() => Sum(i * 200000, (i + 1) * 200000)).Start();

            }
            new Thread(() => Sum(num - (num % 200000), num)).Start();
        }

        private void Sum(int num1, int num2)
        {
            for (int i = num1; i <= num2; i++)
            {
                lock (lockObject)
                {
                    Result += i;
                }
            }
        }
    }
}
