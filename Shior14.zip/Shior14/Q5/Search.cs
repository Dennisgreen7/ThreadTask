﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace Q5
{
    public class Search
    {
        public string Drive { get; set; }
        public string SearchTerm { get; set; }
        public List<string> fileList { get; } = new List<string>();

        public Search(string drive, string searchTerm)
        {
            Drive = drive;
            SearchTerm = searchTerm;
            fileList = Directory.GetFiles(@drive, "*.txt").ToList();
        }

        public Search()
        {
        }
        public List<dynamic> GetFiles()
        {
            DirectoryInfo d = new DirectoryInfo(@Drive);
            object lockObject = new object();
            var relevantFiles = new List<dynamic>();
            foreach (var file in fileList)
            {
                new Thread(() =>
                {
                    if (IsContainsSearchTerm(file.ToString()))
                    {
                        lock (lockObject)
                        {
                            relevantFiles.Add(file);
                        }
                    }
                }).Start();
            }
            return relevantFiles;
        }

        private bool IsContainsSearchTerm(string file)
        {

            string line;
            using (StreamReader reader = new StreamReader(file))
            {
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Contains(SearchTerm))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
