﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread thread1 = new Thread(() =>
            {
                DirectoryInfo d = new DirectoryInfo(@"C:\");
                FileInfo[] Files = d.GetFiles();
                foreach (var file in Files)
                {
                    Console.WriteLine(file.Name); 
                }
            });

            Thread thread2 = new Thread(() =>
            {
                DirectoryInfo d = new DirectoryInfo(@"D:\");
                FileInfo[] Files = d.GetFiles();
                foreach (var file in Files)
                {
                    Console.WriteLine(file.Name);
                }
            });
           
            thread1.Start();
            thread2.Start();
            Task task = new Task(() =>
            {
                DirectoryInfo d1 = new DirectoryInfo(@"C:\");
                FileInfo[] Files1 = d1.GetFiles();
                foreach (var file in Files1)
                {
                    Console.WriteLine(file.Name);
                }
                DirectoryInfo d2 = new DirectoryInfo(@"D:\");
                FileInfo[] Files2 = d2.GetFiles();
                foreach (var file in Files2)
                {
                    Console.WriteLine(file.Name);
                }
            });
            task.Start();
            Console.ReadLine();
        }
    }
}
